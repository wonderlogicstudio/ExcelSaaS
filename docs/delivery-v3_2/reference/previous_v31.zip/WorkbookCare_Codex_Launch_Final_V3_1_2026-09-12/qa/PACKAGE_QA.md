# 최종 패키지 검증 결과

## 실제 수행한 범위

- Python 표준라이브러리 패키지/합성 정답 검사: **19개 test 통과**. 문서·JSON·명령문·의존성·기존 120개 판정/원본 ZIP 보존, 기본/16개 경계 fixture의 내부 일관성, CSV/XLSX 값과 타입, 수식/링크/매크로 없음, SHA-256 목록을 검사했다.
- 가이드 브라우저 점검: **56개 check 통과**. 8개 선택의 명령문/제목/MD링크/산출물, 전체선택, 클립보드 거부 시 대체경로, 실제 TXT 다운로드 본문, 1280/768/390/320 폭의 페이지 넘침, JavaScript 오류를 확인했다.
- Python 도구 구문을 파싱했고 ZIP CRC와 파일별 SHA-256을 확인했다.
- 기존 V3 ZIP과 4개 mapping 파일을 byte 그대로 보존했다. 기본 합성 INPUTS/EXPECTED JSON도 원 V3에서 변경 없이 가져왔다.

## 사용한 명령

```text
python tools/verify_package.py
python tools/check_guide_browser.py --chromium /usr/bin/chromium --content-mode
```

각각 최종 exit code 0. 원본 결과는 `PACKAGE_TEST_RESULTS.txt`, `GUIDE_BROWSER_RESULTS.json`에 있다. 브라우저 기본 Playwright executable 경로가 없어 시스템 Chromium을 사용했다. 환경 정책이 file:// 직접 탐색을 거부하므로 **HTML 본문을 set_content로 로드**해 점검했다. 이를 Windows 더블클릭 또는 실제 file:// 탐색 성공이라고 표현하지 않는다.

## XLSX 입력 검증

artifact_tool로 값 기반 두 입력 XLSX를 생성하고 inspect 및 OOXML의 문자열 키·원금액·수식 부재를 검사했다. `0001` 등의 키가 문자열로 저장된 것을 확인했다. artifact renderer의 선행0 표시가 OOXML과 달라 그 preview는 배포 패키지에서 제외했다. 실제 Windows Excel 렌더링/열기 확인은 수행하지 않았다. CSV의 Excel 직접열기 자동 형변환도 이 검사로 보장하지 않는다.

## 수행하지 않은 것

**WorkbookCare 앱의 실제 파서/엔진/API/UI, 고객 PC의 로컬 프로젝트, Git 변경·push, 운영환경, 클라우드 리소스, PG test/live 결제, Windows Excel, 실제 모바일·스크린리더, OS 클립보드 쓰기/읽기 왕복, 고객 인터뷰·구매**는 검증하지 않았다.

패키지 validator는 고정 정답의 일관성을 검사할 뿐 생산 엔진과 정답을 대조하지 않는다. 실제 제품 테스트는 Codex가 각 묶음에서 구현·실행해 별도 review에 남겨야 한다. 경계 예제는 전체 품질 코퍼스나 외부 정확도 증거가 아니다.

## 출시 판정

`DELIVERY_PACKAGE_VERIFIED / PRODUCT_NOT_IMPLEMENTED_BY_THIS_DELIVERY / RELEASE_NOT_ASSESSED`.

이 문서가 실제 서비스가 준비됐다는 승인 또는 보안 인증을 의미하지 않는다.
