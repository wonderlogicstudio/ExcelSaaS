# 원 요구의 보존

120개 판정표(JSON에는 원 작업 본문 포함)와 CF/UXR 표는 이전 V3 원문 그대로다. 이전 V2.2의 위치를 언급하면 `reference` 안의 V3 ZIP 내부 보존본을 의미한다. 중첩된 옛 ZIP을 실행 문서로 모두 읽거나 앱 위에 풀지 않는다.

KEEP 36 / SLICE 42 / CONSULT 15 / DEFER 27. 새 `bundles/BUNDLES.json`의 legacy_tasks는 관련 묶음의 연결이며 원 task의 전체 완료가 아니다. 기존 implementation/review 완료 이력은 로컬 것을 유지한다.
