"""Validate this instruction package and fixed examples; never call the app/cloud/PG.

Usage: python tools/verify_package.py
Python standard library only. Exits nonzero if package contents are inconsistent.
This is NOT a reconciliation engine or product security/payment test.
"""
from __future__ import annotations

import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import unittest
from urllib.parse import unquote, urlparse
import xml.etree.ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


def load(path: str):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))


def is_integer(value):
    return isinstance(value, str) and re.fullmatch(r'-?\d+', value) is not None


class PackageStructure(unittest.TestCase):
    def test_json_readable(self):
        for path in ROOT.rglob('*.json'):
            with self.subTest(file=str(path.relative_to(ROOT))):
                json.loads(path.read_text(encoding='utf-8'))

    def test_eight_units_and_dependencies(self):
        bundles = load('bundles/BUNDLES.json')
        self.assertEqual([b['id'] for b in bundles], [f'L{i:02}' for i in range(1,9)])
        seen=set()
        for b in bundles:
            self.assertTrue(set(b['dependencies']).issubset(seen))
            seen.add(b['id'])
            self.assertEqual(len(b['read']),2)
            self.assertGreaterEqual(len(b['acceptance']),4)
            self.assertEqual(len(b['owner_steps']),3)
            self.assertNotIn(b['status'], ['APPROVED','COMPLETED'])
            for f in [b['file'],*b['read']]:
                self.assertTrue((ROOT/f).is_file(),f)

    def test_commands_match_text_files(self):
        commands=load('commands.json')
        self.assertEqual(len(commands),8)
        for c in commands:
            body=(ROOT/f"prompts/{c['id']}.txt").read_text(encoding='utf-8')
            self.assertEqual(body.strip(),c['text'].strip())
            self.assertIn(f"이번에는 {c['id']}",body)
            self.assertIn(f"{c['id']} 완료 후 반드시 멈춰라",body)
            self.assertIn('별도 명시 승인 없이',body)
            self.assertIn('초기화하지 마라',body)
        self.assertEqual((ROOT/'CODEX_START_L01.txt').read_text().strip(),commands[0]['text'].strip())

    def test_original_archive_and_mappings_preserved(self):
        info=load('reference/PRESERVATION.json')
        path=ROOT/'reference'/info['previous_package']
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),info['sha256'])
        with ZipFile(path) as z:
            self.assertIsNone(z.testzip())
            prefix='WorkbookCare_Launch_Review_V3_2026-09-12/'
            for p in (ROOT/'mapping').glob('*'):
                if p.name!='README.md':
                    self.assertEqual(p.read_bytes(),z.read(prefix+'mapping/'+p.name))
            self.assertEqual((ROOT/'fixtures/BASELINE_INPUTS.json').read_bytes(),z.read(prefix+'examples/SYNTHETIC_INPUTS.json'))
            self.assertEqual((ROOT/'fixtures/BASELINE_EXPECTED.json').read_bytes(),z.read(prefix+'examples/SYNTHETIC_RESULT.json'))

    def test_legacy_120_dispositions(self):
        tasks=load('mapping/TASK_120_DECISIONS.json')
        self.assertEqual({t['id'] for t in tasks},{f'T{i:03}' for i in range(1,121)})
        self.assertEqual(collections.Counter(t['disposition'] for t in tasks),{'KEEP':36,'SLICE':42,'CONSULT':15,'DEFER':27})
        for t in tasks:self.assertTrue(t['does_not_mark_original_task_completed'])

    def test_markdown_links_exist(self):
        for f in ROOT.rglob('*.md'):
            # Code examples are not navigational links.
            body=re.sub(r'```.*?```','',f.read_text(encoding='utf-8'),flags=re.S)
            for target in re.findall(r'\]\(([^)]+)\)',body):
                if urlparse(target).scheme or target.startswith('#'):continue
                target=unquote(target.split('#',1)[0])
                self.assertTrue((f.parent/target).resolve().exists(),f'{f.relative_to(ROOT)} -> {target}')

    def test_html_embedded_data(self):
        text=(ROOT/'START_HERE.html').read_text()
        m=re.search(r'<script id="packageData" type="application/json">(.*?)</script>',text,re.S)
        self.assertIsNotNone(m)
        data=json.loads(m.group(1))
        self.assertEqual(data['commands'],load('commands.json'))
        self.assertEqual(data['bundles'],load('bundles/BUNDLES.json'))
        self.assertNotIn('fetch(',text)
        self.assertNotIn('localStorage',text)
        self.assertIn('readonly',text)

    def test_html_local_links_exist(self):
        text=(ROOT/'START_HERE.html').read_text()
        for target in re.findall(r'href="([^"]+)"',text):
            if target.startswith('#') or urlparse(target).scheme:continue
            self.assertTrue((ROOT/target.split('#',1)[0]).exists(),target)

    def test_templates_not_approvals(self):
        p=load('templates/launch-progress.example.json')
        self.assertTrue(p['template_only'])
        self.assertTrue(p['must_not_overwrite_existing_progress'])
        self.assertFalse(p['release']['owner_release_approval'])
        self.assertIsNone(p['current_approved_bundle'])
        self.assertFalse((ROOT/'launch-progress.json').exists())
        self.assertFalse((ROOT/'owner_action.md').exists())

    def test_no_real_secrets(self):
        for p in ROOT.rglob('*'):
            if p.is_file() and p.suffix in {'.md','.json','.txt','.html','.py'}:
                body=p.read_text(encoding='utf-8')
                self.assertNotRegex(body,r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')
        self.assertFalse(list(ROOT.rglob('.env')))


class SyntheticFixtureConsistency(unittest.TestCase):
    """Check fixed expected data, not a production or reference matching engine."""
    def setUp(self):
        self.inputs=load('fixtures/BASELINE_INPUTS.json')
        self.expected=load('fixtures/BASELINE_EXPECTED.json')

    def test_counts_and_rows_preserved(self):
        records=self.expected['records']
        self.assertEqual(len(records),8)
        self.assertEqual(collections.Counter(r['status'] for r in records),self.inputs['expected_counts'])
        for side in ['A','B']:
            assigned=[i for r in records for i in r[side]]
            self.assertEqual(sorted(assigned),list(range(1,len(self.inputs[side])+1)))
            self.assertEqual(len(assigned),len(set(assigned)))

    def test_known_totals_and_conservation(self):
        total={}
        unknown={}
        for side in ['A','B']:
            amounts=[r['amount'] for r in self.inputs[side]]
            total[side]=sum(int(v) for v in amounts if is_integer(v))
            unknown[side]=sum(not is_integer(v) for v in amounts)
            self.assertEqual(str(total[side]),self.inputs['expected_known_totals'][side])
        records=self.expected['records']
        pair=sum(int(r['delta']) for r in records if r['status'] in ['MATCHED','AMOUNT_DIFF'])
        onlyA=sum(int(r['amount_A']) for r in records if r['status']=='ONLY_A')
        onlyB=sum(int(r['amount_B']) for r in records if r['status']=='ONLY_B')
        uncomp={s:sum(int(self.inputs[s][i-1]['amount']) for r in records if r['status'] in ['AMBIGUOUS','INPUT_ERROR'] for i in r[s] if is_integer(self.inputs[s][i-1]['amount'])) for s in ['A','B']}
        self.assertEqual(total['A']-total['B'],pair+onlyA-onlyB+uncomp['A']-uncomp['B'])
        self.assertEqual(total,{'A':47900,'B':51000})
        self.assertEqual(uncomp,{'A':5900,'B':6000})
        self.assertEqual(unknown,{'A':1,'B':0})

    def test_baseline_invalid_counterpart_retained(self):
        r=next(x for x in self.expected['records'] if x['key']=='0007')
        self.assertEqual(r['status'],'INPUT_ERROR');self.assertEqual(r['A'],[8]);self.assertEqual(r['B'],[6]);self.assertIsNone(r['delta'])

    def test_edge_cases_have_complete_fixed_partitions(self):
        cases=load('fixtures/EDGE_CASES.json')['cases']
        self.assertEqual(len(cases),16)
        self.assertEqual({c['id'] for c in cases},{f'E{i:02}' for i in range(1,17)})
        for c in cases:
            with self.subTest(case=c['id']):
                for side in ['A','B']:
                    ids=[i for r in c['expected'] for i in r[side]]
                    self.assertEqual(sorted(ids),list(range(1,len(c[side])+1)))
                for r in c['expected']:
                    if r['status'] in ['MATCHED','AMOUNT_DIFF']:
                        self.assertEqual(len(r['A']),1);self.assertEqual(len(r['B']),1)
                        a=c['A'][r['A'][0]-1];b=c['B'][r['B'][0]-1]
                        self.assertEqual(a['key_parts'],b['key_parts'])
                        delta=int(a['amount'])-int(b['amount'])
                        self.assertEqual(str(delta),r['delta'])
                        self.assertEqual(r['status']=='MATCHED',abs(delta)<=int(c['policy']['tolerance_krw']))
                    else:self.assertIsNone(r['delta'])

    def test_edge_preflight_is_not_paid_permission(self):
        for c in load('fixtures/EDGE_CASES.json')['cases']:
            pairs=[r for r in c['expected'] if r['status'] in ['MATCHED','AMOUNT_DIFF']]
            if not pairs:self.assertEqual(c['expected_preflight'],'NOT_ELIGIBLE')
            elif any(r['status'] in ['AMBIGUOUS','INPUT_ERROR'] for r in c['expected']):self.assertEqual(c['expected_preflight'],'ELIGIBLE_WITH_LIMITATIONS')

    def test_csv_matches_baseline(self):
        for side in ['A','B']:
            p=ROOT/f'fixtures/acceptance_{side}.csv'
            self.assertTrue(p.read_bytes().startswith(b'\xef\xbb\xbf'))
            with p.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.reader(f))
            self.assertEqual(rows[0],['거래번호','금액'])
            self.assertEqual(rows[1:],[[r['key'],r['amount']] for r in self.inputs[side]])

    def test_xlsx_text_keys_and_values(self):
        for side in ['A','B']:
            with ZipFile(ROOT/f'fixtures/acceptance_{side}.xlsx') as z:
                self.assertIsNone(z.testzip())
                xml=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                cells={c.get('r'):c for c in xml.findall('.//m:c',NS)}
                for idx,row in enumerate(self.inputs[side],2):
                    c=cells[f'A{idx}'];v=c.find('m:v',NS)
                    self.assertIn(c.get('t'),['str','inlineStr','s'])
                    self.assertEqual('' if v is None else (v.text or ''),row['key'])
                    amount=cells[f'B{idx}'].find('m:v',NS).text
                    self.assertEqual(amount,row['amount'])

    def test_xlsx_no_formula_macro_or_link(self):
        for side in ['A','B']:
            with ZipFile(ROOT/f'fixtures/acceptance_{side}.xlsx') as z:
                for name in z.namelist():
                    lower=name.lower()
                    self.assertNotIn('vbaproject',lower);self.assertNotIn('externallinks/',lower)
                    if name.startswith('xl/worksheets/') and name.endswith('.xml'):
                        xml=ET.fromstring(z.read(name))
                        self.assertFalse(xml.findall('.//m:f',NS))
                        self.assertFalse(xml.findall('.//m:hyperlink',NS))


class HashInventory(unittest.TestCase):
    def test_checksum_inventory(self):
        path=ROOT/'CHECKSUMS.sha256'
        self.assertTrue(path.is_file(),'Missing final inventory')
        for line in path.read_text().splitlines():
            digest,rel=line.split('  ',1)
            file=(ROOT/rel).resolve()
            self.assertTrue(file.is_relative_to(ROOT.resolve()),rel)
            self.assertTrue(file.is_file(),rel)
            self.assertEqual(hashlib.sha256(file.read_bytes()).hexdigest(),digest,rel)


if __name__=='__main__':
    print('PACKAGE/EXAMPLE VALIDATION ONLY — WorkbookCare app, Excel, PG, cloud: NOT RUN.',flush=True)
    unittest.main(verbosity=2)
