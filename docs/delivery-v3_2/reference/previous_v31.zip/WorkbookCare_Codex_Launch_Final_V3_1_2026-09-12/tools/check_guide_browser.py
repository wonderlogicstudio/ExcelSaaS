"""Optional offline guide QA. Requires Playwright and a Chromium executable.
Not an application, PG or operating-system clipboard verification.
Usage: python tools/check_guide_browser.py [--chromium /usr/bin/chromium]
Writes qa/GUIDE_BROWSER_RESULTS.json and two screenshots inside this package.
Re-running changes QA files; regenerate CHECKSUMS.sha256 for a redistributed copy.
"""
import argparse
import json
from pathlib import Path
import tempfile
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
commands=json.loads((ROOT/'commands.json').read_text(encoding='utf-8'))
parser=argparse.ArgumentParser()
parser.add_argument('--chromium',default=None)
parser.add_argument('--content-mode',action='store_true',help='Load HTML source, not file://; does not verify direct navigation')
args=parser.parse_args()
results=[]

def check(name, ok):
    results.append({'name':name,'passed':bool(ok)})
    if not ok:raise AssertionError(name)

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,**({'executable_path':args.chromium} if args.chromium else {}))
    page=browser.new_page(viewport={'width':1280,'height':900},accept_downloads=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    if args.content_mode:
        page.set_content((ROOT/'START_HERE.html').read_text(encoding='utf-8'),wait_until='load')
    else:
        page.goto((ROOT/'START_HERE.html').as_uri(),wait_until='load')
    check('html_source_loaded' if args.content_mode else 'direct_file_navigation',page.title().startswith('WorkbookCare'))
    check('eight_bundle_options',page.locator('#bundleSelect option').count()==8)
    for cmd in commands:
        page.select_option('#bundleSelect',cmd['id'])
        check(cmd['id']+'_exact_prompt',page.locator('#promptText').input_value()==cmd['text'])
        check(cmd['id']+'_title',page.locator('#selectedTitle').inner_text().startswith(cmd['id']))
        check(cmd['id']+'_md_link',page.locator('#bundleLink').get_attribute('href')==cmd['file'])
        check(cmd['id']+'_deliverables',page.locator('#deliverables li').count()==3)
        check(cmd['id']+'_stop_instruction',f"{cmd['id']} 완료 후 반드시 멈춰라" in page.locator('#promptText').input_value())
    page.select_option('#bundleSelect','L01')
    page.locator('#selectBtn').click()
    sel=page.locator('#promptText').evaluate('(e)=>({start:e.selectionStart,end:e.selectionEnd,n:e.value.length})')
    check('select_all_fallback',sel['start']==0 and sel['end']==sel['n'])
    # Deterministically exercise clipboard-denied fallback, not OS clipboard success.
    page.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:()=>Promise.reject(new Error('Denied for fallback QA'))}})")
    page.locator('#copyBtn').click()
    page.wait_for_function("document.getElementById('copyStatus').textContent.includes('제한')")
    check('denied_clipboard_message','자동 복사가 제한' in page.locator('#copyStatus').inner_text())
    check('denied_clipboard_selection',page.locator('#promptText').evaluate('(e)=>e.selectionEnd===e.value.length'))
    with page.expect_download() as event:page.locator('#downloadBtn').click()
    download=event.value
    with tempfile.TemporaryDirectory() as tmp:
        target=Path(tmp)/'command.txt';download.save_as(target)
        check('txt_download_filename',download.suggested_filename=='WorkbookCare_L01_Codex.txt')
        check('txt_download_body',target.read_text(encoding='utf-8-sig')==commands[0]['text'])
    for width in [1280,768,390,320]:
        page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(50)
        check('no_page_horizontal_overflow_'+str(width),page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'))
        check('textarea_in_viewport_'+str(width),page.locator('#promptText').evaluate('(e)=>e.getBoundingClientRect().width <= innerWidth'))
    page.set_viewport_size({'width':1280,'height':900});page.evaluate('scrollTo(0,0)')
    page.screenshot(path=str(ROOT/'qa/GUIDE_DESKTOP.png'),full_page=False)
    page.set_viewport_size({'width':390,'height':844});page.evaluate('scrollTo(0,0)')
    page.screenshot(path=str(ROOT/'qa/GUIDE_MOBILE.png'),full_page=False)
    check('no_javascript_errors',not errors)
    version=browser.version;browser.close()
report={'scope':'OFFLINE_GUIDE_ONLY','browser':version,'navigation':'HTML source set_content (file:// blocked by environment policy)' if args.content_mode else 'file:// in container Chromium','checks':results,'passed':len(results),'failed':0,
 'not_tested':['Windows double click','Operating-system clipboard write/read roundtrip','Physical mobile device','Screen reader','WorkbookCare app','Excel desktop','PG','Cloud deployment']}
(ROOT/'qa/GUIDE_BROWSER_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':len(results),'failed':0,'scope':report['scope']},ensure_ascii=False))
